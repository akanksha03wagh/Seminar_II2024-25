function loadCart() {
  const cartContainer = document.getElementById('cart-container');
  const totalPriceElem = document.getElementById('total-price');
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  cartContainer.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;

    const itemDiv = document.createElement("div");
    itemDiv.className = "cart-item";
    itemDiv.innerHTML = `
      <img src="${item.image}" alt="${item.name}" width="80" height="80">
      <div class="cart-details">
        <h3>${item.name}</h3>
        <p>Price: ₹${item.price}</p>
        <input type="number" value="${item.quantity}" min="1" data-index="${index}" class="quantity-input" />
      </div>
      <button class="remove-btn" data-index="${index}">Remove</button>
    `;

    cartContainer.appendChild(itemDiv);
  });

  totalPriceElem.textContent = `Total: ₹${total}`;
  localStorage.setItem("orderTotal", total); // ✅ Send total to checkout page
}

document.addEventListener("DOMContentLoaded", () => {
  loadCart();

  // Remove item
  document.getElementById("cart-container").addEventListener("click", function (e) {
    if (e.target.classList.contains("remove-btn")) {
      const index = e.target.getAttribute("data-index");
      let cart = JSON.parse(localStorage.getItem("cart")) || [];
      cart.splice(index, 1);
      localStorage.setItem("cart", JSON.stringify(cart));
      loadCart();
    }
  });

  // Quantity change
  document.getElementById("cart-container").addEventListener("change", function (e) {
    if (e.target.classList.contains("quantity-input")) {
      const index = e.target.getAttribute("data-index");
      let newQuantity = parseInt(e.target.value);
      if (isNaN(newQuantity) || newQuantity < 1) newQuantity = 1;

      let cart = JSON.parse(localStorage.getItem("cart")) || [];
      cart[index].quantity = newQuantity;
      localStorage.setItem("cart", JSON.stringify(cart));
      loadCart();
    }
  });
});

// ✅ Preload products if cart is empty
if (!localStorage.getItem("cart")) {
  const sampleCart = [
    {
      name: "Turmeric Powder",
      price: 150,
      quantity: 2,
      image: "images/turmeric.jpg"
    },
    {
      name: "Cardamom Pods",
      price: 250,
      quantity: 1,
      image: "images/cardamom.jpg"
    },
    {
      name: "Cinnamon Sticks",
      price: 120,
      quantity: 1,
      image: "images/cinnamon.jpg"
    }
  ];
  localStorage.setItem("cart", JSON.stringify(sampleCart));
}
