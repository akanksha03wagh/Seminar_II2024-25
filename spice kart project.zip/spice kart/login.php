<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $conn = new mysqli("localhost", "root", "", "spicekart");
  if ($conn->connect_error) die("DB Error");

  $email = $_POST['email'];
  $password = $_POST['password'];

  $result = $conn->query("SELECT * FROM users WHERE email='$email'");
  if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    if (password_verify($password, $user['password'])) {
      echo "<script>alert('Login Successful!'); window.location.href='index.html';</script>";
    } else {
      echo "<script>alert('Incorrect password!'); window.location.href='login.php';</script>";
    }
  } else {
    echo "<script>alert('User not found! Please register.'); window.location.href='register.php';</script>";
  }
  $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login - SpiceKart</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="login.css">
</head>
<body>
  <header class="navbar">
    <div class="logo">SpiceKart 🌶️</div>
    <nav class="nav-links">
      <a href="index.html">Home</a>
      <a href="product.html">Product</a>
      <a href="about.html">About</a>
      <a href="contact.html">Contact</a>
      <a href="login.php">Login</a>
      <a href="register.php">Register</a>
      <a href="help.html">Help & Support</a>

       <div class="profile-wrap" style="display: flex; align-items: center; gap: 8px;">
        <a href="profile.html">
          <img src="images/profile_icon.jpg" alt="Profile" style="width: 32px; height: 32px; border-radius: 50%;" />
        </a>
        <span id="username" style="color: white; font-weight: bold;"></span>
      </div>
    </nav>
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
    </nav>
  </header>

  <section class="login-section">
    <div class="login-container">
      <h1>Login to SpiceKart</h1>
      <form class="login-form" method="POST">
        <label>Email</label>
        <input type="email" name="email" placeholder="Enter your email" required />

        <label>Password</label>
        <input type="password" name="password" placeholder="Enter your password" required />

        <button type="submit" class="btn">Login</button>
        <p class="extra">Don't have an account? <a href="register.php">Register here</a>.</p>
      </form>
    </div>
  </section>
</body>
</html>
